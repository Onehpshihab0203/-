#!/usr/bin/env bash
# Usage: ./push.sh https://github.com/<user>/<repo>.git
set -e
[ -z "$1" ] && { echo "Usage: ./push.sh <github-repo-url>"; exit 1; }
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin "$1"
git push -u origin main
echo "Now enable Settings -> Pages -> main / root on GitHub."
