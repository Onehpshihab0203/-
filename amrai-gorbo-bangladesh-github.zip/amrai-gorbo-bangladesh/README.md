# আমরাই গড়ব বাংলাদেশ (Amrai Gorbo Bangladesh)

A single-file demo web app (no build step, no dependencies):
- Bangla / English toggle
- Demo contribution flow: bKash, Nagad, Visa card + BDT amount (demo only, no real payment)
- Crop guide (12 crops), camera / photo scan (demo result)
- 64 districts, DAE help contacts, national hotline 16123
- Weather snapshot (18 Oct 2026) and live Dhaka clock
- JolMati AI demo, roadmap, business model

## Run locally
Open `index.html` in a browser. (Camera needs https or localhost.)
Or: `python3 -m http.server 8000` then visit http://localhost:8000

## Publish on GitHub Pages
1. Create an empty repo on github.com (e.g. `amrai-gorbo-bangladesh`).
2. In this folder run:
   ```
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/<your-username>/amrai-gorbo-bangladesh.git
   git push -u origin main
   ```
3. On GitHub: Settings → Pages → Source: "Deploy from a branch" → Branch: `main`, folder `/ (root)` → Save.
4. After a minute your site is at `https://<your-username>.github.io/amrai-gorbo-bangladesh/`

## Other free hosts
Netlify Drop (drag this folder onto app.netlify.com/drop), Vercel, Cloudflare Pages.

## Notes
- Payments are a UI demo only. For real payments integrate official gateways (bKash, Nagad, SSLCommerz) on a server.
- Weather values are a static snapshot; connect a weather API through a backend to make them live.
- Officer contacts (from a 2021 list) may be outdated. Verify before use.
- You need permission to use the photos embedded in the page.
